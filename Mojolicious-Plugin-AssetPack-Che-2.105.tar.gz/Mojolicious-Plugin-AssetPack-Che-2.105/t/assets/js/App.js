import R from './App.html.vue'
import Hello from './components/Hello.js'

export default {
  name: 'App',
  components: {
    Hello
  },
  render:R.render,
}


